/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package classicapplet1;

import javacard.framework.*;

/**
 *
 * @author yashp
 */
public class ClassicApplet1 extends Applet {

  private byte[] received;

    private static final short MAX_LENGTH = 256;
    private static final byte[] helloFidesmo={(byte)'H',(byte)'e',(byte)'l',(byte)'l',(byte)'o',(byte)' ',(byte)'F',(byte)'i',(byte)'d',(byte)'e',(byte)'s',(byte)'m',(byte)'o',(byte)'!'};
    public static void install(byte[] bArray, short bOffset, byte bLength) {
        new ClassicApplet1();
    }

    /**
     * Only this class's install method should create the applet object.
     */
    protected ClassicApplet1() {
        received = new byte[MAX_LENGTH]; 
        register();
    }

    public void process(APDU apdu) {
        byte buffer[] = apdu.getBuffer();
        short length = (short) helloFidesmo.length; 
        Util.arrayCopyNonAtomic(helloFidesmo, (short)0, buffer, (short)0, (short)length); 
        apdu.setOutgoingAndSend((short)0, length);

    }
}
