/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closeablesimplewarning;

import java.awt.Color;
import java.awt.Frame;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class CloseableSimpleWarning extends Frame implements WindowListener {

        static private final int frame_height = 150;
        static private final int frame_width = 250;

        public CloseableSimpleWarning() {
            setBackground(Color.gray);
            setForeground(Color.black);
            setTitle("HCI");
            setSize(frame_width, frame_height);
            addWindowListener(this);
        }

        @Override

        public void windowClosing(WindowEvent e) {
            System.out.println("Window is closing.");
            dispose();

        }

        public void windowClosed(WindowEvent e) {
            System.out.println("Window closed.");

        }

        @Override

        public void windowIconified(WindowEvent e) {
            System.out.println("Window iconified.");

        }

        @Override

        public void windowDeiconified(WindowEvent e) {
            System.out.println("Window deiconified.");

        }

        @Override

        public void windowOpened(WindowEvent e) {
            System.out.println("Window opened.");

        }

        @Override

        public void windowActivated(WindowEvent e) {
            System.out.println("Window activated.");

        }

        @Override

        public void windowDeactivated(WindowEvent e) {

            System.out.println("Window deactivated.");

        }

        public static void main(String[] args) {
            CloseableSimpleWarning f = new CloseableSimpleWarning();
            f.setVisible(true);
        }

    }
